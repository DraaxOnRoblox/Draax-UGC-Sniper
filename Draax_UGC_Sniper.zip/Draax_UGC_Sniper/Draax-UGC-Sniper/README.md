# [Draax UGC Sniper] (https://dsc.gg/draax)

A free UGC sniper bot for roblox that snipes limiteds.  

## Features
* Different sniping modes afk, regular, time
* Multicookie support
* Incredible speed
* Proxy support
* Buy free and paid ugcs
* Highly customizable
* Make your own themes
* Free, and safe to use
* Windows, Mobile, Unix, Linux support


## How to create a theme
* Copy paste and rename baseTheme
* Put your path to the theme into current theme in the config
* Edit mainlogo.txt for the logo and printText.txt for the printed text  
**TIP - For all variabled and colours see themes/required.json**
