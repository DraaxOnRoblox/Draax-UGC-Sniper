try: from .events import start, iteration, end, error, on_load, buy, ratelimit
except ModuleNotFoundError: pass